#ifndef ESTANTE_H
#define ESTANTE_H

#include <objeto.h>

class Estante : public Objeto
{
public:
    Estante();
    void desenha();
};

#endif
