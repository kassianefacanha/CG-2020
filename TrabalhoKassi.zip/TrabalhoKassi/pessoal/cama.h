#ifndef CAMA_H
#define CAMA_H

#include <objeto.h>

class Cama : public Objeto
{
public:
    Cama();
    void desenha();
};

#endif
